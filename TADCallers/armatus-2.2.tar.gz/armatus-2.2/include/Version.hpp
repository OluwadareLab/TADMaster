#ifndef __VERSION_HPP__
#define __VERSION_HPP__

#endif // __VERSION_HPP__