
from django import forms


#class Method(forms.Form):
#   return null