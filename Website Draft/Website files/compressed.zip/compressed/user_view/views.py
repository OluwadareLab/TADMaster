from django.shortcuts import render

# Create your views here


def index(request):
    return render(request, 'landing.html')


def data_entry(request):
    return render(request, 'data_entry.html')


def tad_methods(request):
    return render(request, 'tad_methods.html')


def normalizations(request):
    return render(request, 'normalizations.html')


def review(request):
    return render(request, 'review.html')