from django.apps import AppConfig


class UserViewConfig(AppConfig):
    name = 'user_view'
