from django.db import models
import random
import time
from datetime import datetime

from django.contrib.auth.models import AbstractUser, UserManager
from django.contrib.gis.db import models
from django.utils.timezone import make_aware


class Job(models.Model):
    # user = models.ForeignKey(CustomUser, related_name="user", on_delete=models.DO_NOTHING)

    created_on = models.DateTimeField(auto_now_add=True)
    priority = models.PositiveIntegerField(default=0)

    job_status = models.PositiveIntegerField(default=0)
    job_id = models.CharField(max_length=60, default="default")

    estimated_completion = models.PositiveIntegerField(default=0)  # in seconds


class Method(models.Model):

    # this foreign key sets a many to one relationship
    job = models.ForeignKey(Job, related_name="method", on_delete=models.DO_NOTHING)

    resource_consumption = models.PositiveIntegerField(default=0)
    name = models.CharField(max_length=60, default="default")
    created_on = models.DateTimeField(auto_now_add=True)


class Variable(models.Model):

    # this foreign key sets a many to one relationship
    method = models.ForeignKey(Job, related_name="variables", on_delete=models.DO_NOTHING)

    class StringVar(models.Model):

        name = models.CharField(max_length=60, default="default")


class Normalization(models.Model):

    # this foreign key sets a many to one relationship
    method = models.ForeignKey(Method, related_name="norm", on_delete=models.DO_NOTHING)

    resource_consumption = models.PositiveIntegerField(default=0)
    name = models.CharField(max_length=60, default="default")
    created_on = models.DateTimeField(auto_now_add=True)

