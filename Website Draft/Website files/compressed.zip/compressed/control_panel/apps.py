from django.apps import AppConfig


class ControlPanelConfig(AppConfig):
    name = 'control_panel'
